from __future__ import division, print_function, absolute_import, unicode_literals
import matplotlib.pyplot as plt
import vplot as vpl

# Figure 5 --> low e/i case

#Left (short)
output = vpl.GetOutput('circ_copl')

fig, ax = plt.subplots(2,2, figsize = (7,9))
plt.rcParams.update({'font.size':12})

#Eccentricity
vpl.plot(ax[0,0],output.star.Time, output.b.Eccentricity, label='b',color=vpl.colors.pale_blue) # planet b
vpl.plot(ax[0,0],output.star.Time, output.c.Eccentricity, label='c',color=vpl.colors.orange) # planet c

#Inclination
vpl.plot(ax[1,0],output.star.Time, output.b.Inc, label='b', color=vpl.colors.pale_blue) # planet b
vpl.plot(ax[1,0],output.star.Time, output.c.Inc, label='c', color=vpl.colors.orange) # planet c



#Right 
output = vpl.GetOutput('circ_copl_long')

#Eccentricity
vpl.plot(ax[0,1],output.star.Time, output.b.Eccentricity, label='b', color=vpl.colors.pale_blue) # planet b
vpl.plot(ax[0,1],output.star.Time, output.c.Eccentricity, label='c', color=vpl.colors.orange) # planet c
#Inclination
vpl.plot(ax[1,1],output.star.Time, output.b.Inc, label='b', color=vpl.colors.pale_blue) # planet b
vpl.plot(ax[1,1],output.star.Time, output.c.Inc, label='c', color=vpl.colors.orange) # planet c

fig.subplots_adjust(wspace=0.001, hspace = 0.01)
#Formatting
ax[0,0].set_ylabel('Eccentricity')
ax[0,0].set_ylim(0.0002,0.0012)
ax[0,0].set_xlim(0,1*(10**6))
ax[1,0].set_xlim(0,1*(10**6))
ax[0,1].set_ylabel('')
ax[0,1].set_ylim(0.0002,0.0012)
ax[1,0].set_ylabel('Inclination ($^\circ$)')
ax[1,1].set_ylabel('')
ax[0,0].legend(loc=3)
ax[0,0].set_xlabel('Time (year)')
ax[0,1].set_xlabel('Time (year)')
ax[1,0].set_xlabel('Time (year)')
ax[1,1].set_xlabel('Time (year)')

vpl.show()

